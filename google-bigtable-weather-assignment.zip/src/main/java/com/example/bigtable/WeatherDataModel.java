package com.example.bigtable;

public class WeatherDataModel {
    public String sensorId;
    public String timestamp;
    public double temperature;
    public double humidity;
    public double windSpeed;
}
